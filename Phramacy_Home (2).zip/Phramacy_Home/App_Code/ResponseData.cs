﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ResponseData
/// </summary>
public class ResponseData
{
    public ResponseData()
    {
        
    }
    public List<Dictionary<String, String>> listdata
    {
        get; set;
    }
    public bool status { get; set; }
    public string message { get; set; }
    public int NoOfRecord { get; set; }


}