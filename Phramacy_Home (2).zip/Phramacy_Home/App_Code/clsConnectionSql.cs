﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.IO;


/// <summary>
/// Summary description for clsConnectionSql
/// </summary>
public class clsConnectionSql
{
	public clsConnectionSql()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public static string passwd = "";
    public static string rpt = "";
    public static string idd = "";
    public static decimal total_amount = 0;
    public static decimal Advance_approval = 0;
    public static int sellingid;
    public static int Approval_id; public static int creditNoteId;
    public static SqlCommand cmd = new SqlCommand();
    public static SqlDataAdapter adpt = new SqlDataAdapter();
    public static SqlConnection con = new SqlConnection();
    public static SqlConnection con1 = new SqlConnection();
    public static DataSet ds = new DataSet();
    public static int Company_id = 1;
    public static int branch_id = 1;
    public static int location_id = 1;
    public static int User_id;
    public static string User_name = "";
    public static Boolean leave_app = false;
    public static Boolean incremnt_chk = false;
    public static string passwordCheck = "";

    //1st Method: To Export to Word, Excel file
    public static void ExportFile(string fileName, string contentType, GridView GVExport)
    {
        //disable paging to export all data and make sure to bind griddata before begin
        //GVExport.AllowPaging = false;
        //LoadGridData();
        //Response.ClearContent();
        //Response.Buffer = true;
        //Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", fileName));
        //Response.ContentType = contentType;
        //StringWriter objSW = new StringWriter();
        //HtmlTextWriter objTW = new HtmlTextWriter(objSW);
        //grdResultDetails.RenderControl(objTW);
        //Response.Write(objSW);
        //Response.End();
    }

    //2nd Method: To Export to CSV, Text file
    public static void ExportTextBasedFile(string fileName, string contentType)
    {
        //disable paging to export all data and make sure to bind griddata before begin
        //grdResultDetails.AllowPaging = false;
        //LoadGridData();

        //Response.ClearContent();
        //Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", fileName));
        //Response.ContentType = contentType;
        //StringBuilder objSB = new StringBuilder();
        //for (int i = 0; i < grdResultDetails.Columns.Count; i++)
        //{
        //    objSB.Append(grdResultDetails.Columns[i].HeaderText + ',');
        //}
        //objSB.Append("\n");
        //for (int j = 0; j < grdResultDetails.Rows.Count; j++)
        //{
        //    for (int k = 0; k < grdResultDetails.Columns.Count; k++)
        //    {
        //        objSB.Append(grdResultDetails.Rows[j].Cells[k].Text + ',');
        //    }
        //    objSB.Append("\n");
        //}
        //Response.Write(objSB.ToString());
        //Response.End();
    }

    public static void ExportToWord(GridView GVExport)
    {
        //Response.Clear();
        //Response.Buffer = true;
        //Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.doc");
        //Response.Charset = "";
        //Response.ContentType = "application/vnd.ms-word ";
        //StringWriter sw = new StringWriter();
        //HtmlTextWriter hw = new HtmlTextWriter(sw);
        //GVExport.AllowPaging = false;
        //GVExport.DataBind();
        //GVExport.RenderControl(hw);
        //Response.Output.Write(sw.ToString());
        //Response.Flush();
        //Response.End();
    }

    public static void ExportToExcel(GridView GVExport)
    { }

    public static void ExportToPDF(GridView GVExport)
    { }

    public static void ExportToCSV(GridView GVExport)
    { }

    public static void ExportToPrint(GridView GVExport)
    { }

    public static List<DateTime> GetDateRange(DateTime StartingDate, DateTime EndingDate)
    {
        if (StartingDate > EndingDate)
        {
            return null;
        }
        List<DateTime> rv = new List<DateTime>();
        DateTime tmpDate = StartingDate;
        do
        {
            rv.Add(tmpDate);
            tmpDate = tmpDate.AddDays(1);
        } while (tmpDate <= EndingDate);
        return rv;
    }

    public static void connectsql()
    {
        con.ConnectionString = Connection.connects();
    }

    public static void conpro()
    {
        clsConnectionSql.con.ConnectionString = Connection.connects();
        clsConnectionSql.con.Open();
        clsConnectionSql.cmd = new SqlCommand();
        clsConnectionSql.cmd.Connection = clsConnectionSql.con;
        clsConnectionSql.cmd.CommandType = CommandType.StoredProcedure;
    }

    public static DataSet fillds(string qry)
    {
        DataSet ds = new DataSet();
        con.ConnectionString = Connection.connects();
        con.Close();
        try
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = qry;
            adpt.SelectCommand = cmd;
            ds.Tables.Clear();
            adpt.Fill(ds);
            con.Close();
            
        }
        catch (Exception)
        {
           // HandleEx.LogFileWrite(HandleEx.CreateErrorMessage(ex));
        }
        return (ds);
    }

    public static DataSet fillds1(string qry)
    {
        DataSet ds = new DataSet();
        con.ConnectionString = Connection.connects();
        con.Close();
        try
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = qry;
            adpt.SelectCommand = cmd;
            ds.Tables.Clear();
            adpt.Fill(ds);
            con.Close();
            
        }
        catch (Exception )
        {
           // HandleEx.LogFileWrite(HandleEx.CreateErrorMessage(ex));
        }
        return (ds);
    }

    public static DataTable fill_SP(string qryy)
    {
        con.ConnectionString = Connection.connects();
        con.Close();
        DataTable dt = new DataTable();
        try
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = qryy;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            adpt = new SqlDataAdapter(cmd);
            adpt.Fill(dt);
            con.Close();
            qryy = "";
            
        }
        catch (Exception )
        {
            
           // HandleEx.LogFileWrite(HandleEx.CreateErrorMessage(ex));
        }
        return (dt);
    }

    public static DataTable filldt(string qry)
    {
        /* if (con.State = ConnectionState.Open)
         {
             con.Close();
         }*/
        //DataTable dt = new DataTable();
        con.ConnectionString = Connection.connects();
        DataTable dt1 = new DataTable();
        try
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = qry;
            adpt.SelectCommand = cmd;
            dt1.Clear();
            adpt.Fill(dt1);
            con.Close();
            
        }
        catch (Exception ex)
        {
           // HandleEx.LogFileWrite(HandleEx.CreateErrorMessage(ex));
        }
        return (dt1);
    }

    //public static SqlDataReader filldr(string qry)
    //{
    //    SqlDataReader dr;
    //    con.ConnectionString = Connection.connect();
    //    //con.Close();
    //    con.Close();
    //    try
    //    {
    //        con.Open();
    //        cmd.Connection = con;
    //        cmd.CommandText = qry;
    //        return (cmd.ExecuteReader(CommandBehavior.CloseConnection));
    //    }
    //    catch (Exception ex)
    //    {
    //        HandleEx.LogFileWrite(HandleEx.CreateErrorMessage(ex));
    //        //return dr;
    //    }
    //}

    public static int Monthdays(int montn)
    {
        Int32 mdays = new int();
        if (montn == 1) { mdays = 31; }
        else if (montn == 2) { mdays = 28; }
        else if (montn == 3) { mdays = 31; }
        else if (montn == 4) { mdays = 30; }
        else if (montn == 5) { mdays = 31; }
        else if (montn == 6) { mdays = 30; }
        else if (montn == 7) { mdays = 31; }
        else if (montn == 8) { mdays = 31; }
        else if (montn == 9) { mdays = 30; }
        else if (montn == 10) { mdays = 31; }
        else if (montn == 11) { mdays = 30; }
        else if (montn == 12) { mdays = 31; }
        return (mdays);
    }

    public static void IUD(string qry)
    {
        con.ConnectionString = Connection.connects();
        con.Close();
        try
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = qry;
            cmd.ExecuteNonQuery();
            con.Close();
        }
        catch (Exception ex)
        {
          //  HandleEx.LogFileWrite(HandleEx.CreateErrorMessage(ex));
        }
    }

    public static void IUD_SP(string SP_Name, string[] Param)
    {
        con.ConnectionString = Connection.connects();
        con.Close();
        try
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = SP_Name;
            cmd.ExecuteNonQuery();
            con.Close();
        }
        catch (Exception ex)
        {
         //   HandleEx.LogFileWrite(HandleEx.CreateErrorMessage(ex));
        }
    }

    public static string sscalar(string qry)
    {
        con.Close();
        try
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = qry;
            string s = cmd.ExecuteScalar().ToString();
            con.Close();
            return (s);
        }
        catch (Exception ex)
        {
          //  HandleEx.LogFileWrite(HandleEx.CreateErrorMessage(ex));
            return "";
        }
    }

    public static void FillCountry(DropDownList cmb)
    {
        string str = "Select * from country_Master  order by Country_name";
        DataTable dt_Country = clsConnectionSql.filldt(str);
        cmb.DataSource = dt_Country;
        cmb.DataValueField = "Country_id";
        cmb.DataTextField = "Country_name";
        cmb.DataBind();
        cmb.Items.Insert(0, new ListItem("Select", "Select"));
        cmb.SelectedIndex = 0;
    }

    public static void FillState(DropDownList cmb)
    {
        string str = "Select * from State_master  order by State_name";
        DataTable dt_Country = clsConnectionSql.filldt(str);
        cmb.DataSource = dt_Country;
        cmb.DataValueField = "State_id";
        cmb.DataTextField = "State_name";
        cmb.DataBind();
        cmb.Items.Insert(0, new ListItem("Select", "Select"));
        cmb.SelectedIndex = 0;
    }

    public static void FillCity(DropDownList cmb)
    {
        string str = "Select * from City_master  order by City_name";
        DataTable dt_Country = clsConnectionSql.filldt(str);
        cmb.DataSource = dt_Country;
        cmb.DataValueField = "City_id";
        cmb.DataTextField = "City_name";
        cmb.DataBind();
        cmb.Items.Insert(0, new ListItem("Select", "Select"));
        cmb.SelectedIndex = 0;
    }

    public static void FillCompany(DropDownList cmb)
    {
        string str = "Select * from CompanyInfo";
        DataTable dt_Country = clsConnectionSql.filldt(str);
        cmb.DataSource = dt_Country;
        cmb.DataValueField = "Company_Id";
        cmb.DataTextField = "Company_Name";
        cmb.DataBind();
        cmb.Items.Insert(0, new ListItem("Select Company Name", "Select"));
        cmb.SelectedIndex = 0;
    }

    public static void FillGrade(DropDownList cmb)
    {
        string str = "Select * from Grade_Master order by GRADENAME";
        DataTable dt_GRADE = clsConnectionSql.filldt(str);
        cmb.DataSource = dt_GRADE;
        cmb.DataValueField = "GRAD_ID";
        cmb.DataTextField = "GRADENAME";
        cmb.DataBind();
        cmb.Items.Insert(0, new ListItem("Select Grade", "Select"));
        cmb.SelectedIndex = 0;
    }

    public static void FillDepartment(DropDownList cmb)
    {
        //string str = "Select * From tbl_department_master where Dept_id>1 order by DeptName ";
        string str = "Select * From tbl_department_master ";
        DataTable dt = clsConnectionSql.filldt(str);
        cmb.DataSource = dt;
        cmb.DataValueField = "Dept_id";
        cmb.DataTextField = "DeptName";
        cmb.DataBind();
        cmb.Items.Insert(0, new ListItem("Select", "Select"));
        cmb.SelectedIndex = 0;
    }

    public static void FillDesignation(DropDownList cmb)
    {
        //string str = "Select * From tbl_designation where Designation_id>1 order by Designation_name ";
        string str = "Select * From tbl_designation  ";
        DataTable dt = clsConnectionSql.filldt(str);
        cmb.DataSource = dt;
        cmb.DataValueField = "Designation_id";
        cmb.DataTextField = "Designation_name";
        cmb.DataBind();
        cmb.Items.Insert(0, new ListItem("Select", "Select"));
        cmb.SelectedIndex = 0;
    }

    public static void FillBank(DropDownList cmb)
    {
        string str = "Select * From tbl_Bank_master  order by Bank_name ";
        //string str = "Select * From tbl_Bank_master where Bank_id>1 order by Bank_name ";
        DataTable dt = clsConnectionSql.filldt(str);
        cmb.DataSource = dt;
        cmb.DataValueField = "Bank_id";
        cmb.DataTextField = "Bank_name";
        cmb.DataBind();
        cmb.Items.Insert(0, new ListItem("Select", "Select"));
        cmb.SelectedIndex = 0;
    }

    public static void FillBranch(DropDownList cmb)
    {
        string str = "Select * From Branch_master ";
        DataTable dt = clsConnectionSql.filldt(str);
        cmb.DataSource = dt;
        cmb.DataValueField = "Branch_id";
        cmb.DataTextField = "Branch_name";
        cmb.DataBind();
        cmb.Items.Insert(0, new ListItem("Select", "Select"));
        cmb.SelectedIndex = 0;
    }

    public static void FillShift(DropDownList cmb)
    {
        string str = "Select * from SHIFT_MASTERS order by SHIFT_NAME";
        DataTable dt_SHIFT = clsConnectionSql.filldt(str);
        cmb.DataSource = dt_SHIFT;
        cmb.DataValueField = "SHIFT_ID";
        cmb.DataTextField = "SHIFT_NAME";
        cmb.DataBind();
        cmb.Items.Insert(0, new ListItem("Select Shift", "Select"));
        cmb.SelectedIndex = 0;
    }

    public static void FillLeave(DropDownList cmb)
    {
        string str = "Select * from tbl_LeaveMaster order by LeaveName";
        DataTable dt_SHIFT = clsConnectionSql.filldt(str);
        cmb.DataSource = dt_SHIFT;
        cmb.DataValueField = "Leave_id";
        cmb.DataTextField = "LeaveName";
        cmb.DataBind();
        cmb.Items.Insert(0, new ListItem("Select Leave", "Leave"));
        cmb.SelectedIndex = 0;
    }

    public static void FillDesign_comp_map(int C_id, DropDownList ddl)
    {
        //Designation
        string strDesig = "Select * From View_Designation_Map_Company where View_Designation_Map_Company.Company_Id=" + C_id;
        DataTable dtDesig = clsConnectionSql.filldt(strDesig);
        if (dtDesig.Rows.Count > 0)
        {
            ddl.DataSource = dtDesig;
            ddl.DataValueField = "Designation_id";
            ddl.DataTextField = "Designation_name";
            ddl.DataBind();
            ddl.Items.Insert(0, new ListItem("Select Designation", ""));
            ddl.SelectedIndex = 0;
        }
    }

    public static void FillGrade_comp_map(int C_id, DropDownList ddl)
    {
        string strGrad = "Select * From View_Grade_Map_Mapping where View_Grade_Map_Mapping.Company_Id=" + C_id;
        DataTable dtGrad = clsConnectionSql.filldt(strGrad);
        if (dtGrad.Rows.Count > 0)
        {
            ddl.DataSource = dtGrad;
            ddl.DataValueField = "GRAD_ID";
            ddl.DataTextField = "GRADENAME";
            ddl.DataBind();
            ddl.Items.Insert(0, new ListItem("Select Grade", ""));
            ddl.SelectedIndex = 0;
        }
    }

    public static void FillDept_comp_map(int C_id, DropDownList ddl)
    {
        string strDepart = "Select * From View_Department_Map_Company where View_Department_Map_Company.Company_Id=" + C_id;
        DataTable dtDepart = clsConnectionSql.filldt(strDepart);
        if (dtDepart.Rows.Count > 0)
        {
            ddl.DataSource = dtDepart;
            ddl.DataValueField = "Dept_id";
            ddl.DataTextField = "DeptName";
            ddl.DataBind();
            ddl.Items.Insert(0, new ListItem("Select Department", ""));
            ddl.SelectedIndex = 0;
        }
        //Grade
    }

    public static void FillcmbUser(DropDownList ddl)
    {
        DataTable dt_Company = clsConnectionSql.filldt("Select * from tbl_Users_master where Users_id >1 ");
        ddl.DataSource = dt_Company;
        ddl.DataValueField = "Users_id";
        ddl.DataTextField = "Users_name";
        ddl.DataBind();  //dr["Users_name"] = "Select User";
        //dr["Users_id"] = 0;
        ddl.Items.Insert(0, new ListItem("Select User", ""));
        ddl.SelectedIndex = 0;
    }

    public static Boolean check_pass;

    public static void check_Password(int userid, string pass)
    {
        string str = "Select * from tbl_Users_master where Users_id=" + userid + " and Password='" + pass.ToString() + "'";
        DataSet ds = clsConnectionSql.fillds(str);
        if (ds.Tables[0].Rows.Count > 0)
        {
            check_pass = true;
        }
        else
        {
            check_pass = false;
        }
    }

    public static void FillGrid(string str, GridView grd)
    {
        DataTable dt_Grid = clsConnectionSql.filldt(str);
        grd.DataSource = dt_Grid;
        grd.DataBind();
    }

    public static void PrepareControlForExport(Control control)
    {
        for (int i = 0; i < control.Controls.Count; i++)
        {
            Control current = control.Controls[i];
            if (current is LinkButton)
            {
                control.Controls.Remove(current);
                //control.Controls.AddAt(i, new LiteralControl((current as LinkButton).Text));
            }
            else if (current is ImageButton)
            {
                control.Controls.Remove(current);
                //control.Controls.AddAt(i, new LiteralControl((current as ImageButton).AlternateText));
            }
            else if (current is HyperLink)
            {
                control.Controls.Remove(current);
                //control.Controls.AddAt(i, new LiteralControl((current as HyperLink).Text));
            }
            else if (current is DropDownList)
            {
                control.Controls.Remove(current);
                //control.Controls.AddAt(i, new LiteralControl((current as DropDownList).SelectedItem.Text));
            }
            else if (current is CheckBox)
            {
                control.Controls.Remove(current);
                //control.Controls.AddAt(i, new LiteralControl((current as CheckBox).Checked ? "True" : "False"));
            }
            else if (current is HiddenField)
            {
                control.Controls.Remove(current);
                //control.Controls.AddAt(i, new LiteralControl((current as CheckBox).Checked ? "True" : "False"));
            }
            if (current.HasControls())
            {
                PrepareControlForExport(current);
            }
        }
    }

    private static int seed;
}