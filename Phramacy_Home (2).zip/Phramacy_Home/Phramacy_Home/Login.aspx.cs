﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    public SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["LPConnectionString"].ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_submit_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtusrname.Text.Length > 0 && txtPass.Text.Length > 0)
            {
                con.Open();
                string str = string.Empty;
                str = "Select count(Id) from AdminMaster where UserId='" + txtusrname.Text + "' and Password='" + txtPass.Text + "' ";
                int cnt = 0;
                cnt = Convert.ToInt32(new SqlCommand(str, con).ExecuteScalar());

                if (cnt > 0)
                {

                    Session["loginTime"] = new SqlCommand("Select  Max(Logintime) from LoginDetail ", con).ExecuteScalar().ToString();
                    SqlCommand com = new SqlCommand("Insert Into LoginDetail(LoginTime) values(dbo.Fn_GetDate())", con);
                    com.ExecuteNonQuery();
                    Session["UserType"] = "Admin";
                    Session["LoginType"] = "Pharmacy";
                    con.Close();
                    Response.Redirect("~/AdminPannel/DashBoard.aspx");
                }
                else
                {

                    //  alertdiv.Style.Add("display", "block");
                    //   Response.Redirect("Login.aspx");
                }




            }
        }
        catch (Exception e1)
        {
            lblerrmsg.Text = e1.Message;
            alertdiv.Style.Add("display", "block");
            // Response.Write(e1.ToString());
        }

    }
}