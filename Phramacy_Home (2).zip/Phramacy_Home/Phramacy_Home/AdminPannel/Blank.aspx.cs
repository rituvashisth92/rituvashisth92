﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using Microsoft.ApplicationBlocks.Data;
using System.Web.UI.WebControls;

public partial class AdminPannel_Blank : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        fetchjob();
        fetchfailmail();
    }

    public void fetchjob()
    {
       
        DataSet jds = Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteDataset(Connection.connects(), CommandType.StoredProcedure, "msdb.dbo.sp_help_jobactivity");
        gvjob.DataSource = jds.Tables[0];
        gvjob.DataBind();
    }

    public void fetchfailmail()
    {

        DataSet jds = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, "SELECT * FROM MSDB.DBO.sysmail_faileditems order by 1 desc ");
        gv_failedmail.DataSource = jds.Tables[0];
        gv_failedmail.DataBind();
    }

    protected void gvjob_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvjob.PageIndex = e.NewPageIndex;
        fetchjob();
    }

    protected void gv_failedmail_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gv_failedmail.PageIndex = e.NewPageIndex;
        fetchfailmail();
    }


    public void sendFailedMAIl()
    {
        try
        {
            string qry = @"DECLARE @to        varchar(max)
DECLARE @copy    varchar(max)
DECLARE @title    nvarchar(255)
DECLARE @msg    nvarchar(max)  
DECLARE FaileMailCursor CURSOR FAST_FORWARD FOR     
SELECT  recipients,  copy_recipients,  [subject], body
FROM msdb.dbo.sysmail_faileditems
OPEN FaileMailCursor      
FETCH NEXT FROM FaileMailCursor INTO @to, @copy, @title,@msg      
WHILE @@FETCH_STATUS = 0    
BEGIN    
 print @copy    
  EXEC msdb.dbo.sp_send_dbmail     
    @profile_name = 'P2',    
    @recipients = @to,    
    @subject = @title,    
    @body = @msg,    
    @body_format = 'HTML'    
 FETCH NEXT FROM FaileMailCursor INTO @to, @copy, @title,@msg      
END        
CLOSE FaileMailCursor     
DEALLOCATE FaileMailCursor";
            string query = qry.Replace(System.Environment.NewLine, " ");
            int i = SqlHelper.ExecuteNonQuery(Connection.connects(), CommandType.Text, query);

        }
        catch (Exception e)
        {
            lbl_msg.Text = e.Message;
        }
    }

    protected void lbsendMail_Click(object sender, EventArgs e)
    {
        sendFailedMAIl();   
    }
}