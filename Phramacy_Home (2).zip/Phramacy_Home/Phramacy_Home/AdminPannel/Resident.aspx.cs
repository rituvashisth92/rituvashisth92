﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Microsoft.ApplicationBlocks.Data;
using System.Configuration;
using System.Net.Mail;
using System.ServiceProcess;
using System.Text;

public partial class AdminPannel_Resident : System.Web.UI.Page
{
    
    public static string  databaseName = "esdata";         

    protected void Page_Load(object sender, EventArgs e)
    {

        //ServiceBase[] ServicesToRun;
        //ServicesToRun = new ServiceBase[]
        //{
        //    new Class1()
        //};
        //ServiceBase.Run(ServicesToRun);
        
        // sendalertMAil("a");
        fetchjob();
        TBCreated.Text = DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString();
        TBModified.Text = DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString();
    }

    public string CreateSQLJob()
    {
        string result = string.Empty;
        //Package which will be executed by SQL Job
        //string PackagePath =
        //Job Name which will be created
        string jobName = TBJName.Text.ToString();
        string sQuery = string.Empty;
        string databaseName = "Esdata"; //name of the database to which 
        string IsRunDaily = "True"; // Run the SQL Job Daily or Not

        //StartTime should be Integer and in the format of hhmmss. 
        //Here 62517 means hh : 6, mm : 25 & ss : 17
        Int32 strartTime =Int32.Parse(tbstarttime.Text.ToString());

        //StartDate should be Integer and in the format of YYYYMMDD. 
        //Here 20130927 means YYYY : 2013, MM : 09, DD : 27
        Int32 startDate = Int32.Parse(Tbjstdate.Text.ToString());
        //string sd = DateTime.Now.ToString("yyyyMMdd");
        //startDate = Convert.ToInt32(sd);
      //  string query = TbQuery.Text.Trim();
       // query = query.Replace(System.Environment.NewLine, " ");    
        sQuery = @" DECLARE @jobId BINARY(16)  EXEC msdb.dbo.sp_add_job @job_name=N'" + jobName + "', @job_id = @jobId OUTPUT ";
        // add cmd shell cmdd 
      //  sQuery = sQuery + " EXEC msdb.dbo.sp_add_jobstep  @job_id=@jobId, @step_name=N'" + tbstepname.Text.ToString() + "',   @step_id=1, @subsystem =N'"+ DDLstepType.SelectedValue.ToString() + "',@command=N"+ "'" + query + " '" + ",@database_name=N'"+databaseName+"'   ";
        // add new step of job for mail cursor
       sQuery=  sQuery + " EXEC msdb.dbo.sp_add_jobstep @job_id = @jobId, @step_name = N'step_sendMail', @step_id = 1, @cmdexec_success_code = 0, @on_fail_action = 3, @database_name=N'" + databaseName + "', @subsystem = N'TSQL', @command = N' Exec " + TBJName.Text.ToString()+"SendMail ' ";



        if (IsRunDaily == "False")
        {
            sQuery = sQuery + @" EXEC msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'" + tbschname.Text.ToString() + "',  @freq_type =1, ";
            sQuery = sQuery + " @active_start_date=" + startDate + ", ";
            sQuery = sQuery + @" @active_end_date=99991231,@active_start_time=" + strartTime + "";

            sQuery = sQuery + @" EXEC msdb.dbo.sp_add_jobserver   @job_id = @jobId, @server_name = N'(local)'";

        }
        else
        {
            sQuery = sQuery + @" EXEC msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'"+tbschname.Text.ToString()+"', @freq_type=4,@freq_interval="+ tbrechr.Text.ToString() + ", ";
            sQuery = sQuery + " @active_start_date=" + startDate + ", ";
            sQuery = sQuery + @" @active_end_date=99991231, @active_start_time=" + strartTime + "";
            sQuery = sQuery + @" EXEC msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'";
        }

        string newSqry = sQuery.Replace(@"\","");
        //Execute SQL Query
        int rowsEffected = ExecuteCommandQuery(newSqry, CommandType.Text);
        if (rowsEffected != -9)
        {
            result = "Job Created Successfully.";

        }
        else
        {
            result = result = "Job Already exists!! or Some error occurred.";
        }
        return result;
    }

    private int ExecuteCommandQuery(string sQuery, CommandType text)
    {
        SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["LPConnectionString"].ToString());
        int rowEffected = 0;
        try
        {
            conn.Open();
            SqlCommand command = new SqlCommand(sQuery, conn);
            command.CommandType = CommandType.Text;
            rowEffected = command.ExecuteNonQuery();// the query has been 
            conn.Close();
            // runTrigger(); 
            //  sendalertMAil(sQuery);
               
            string query = TbQuery.Text.Trim();
            query = query.Replace(System.Environment.NewLine, " ");
            createMailCursor(query,tbColNAme.Text.ToString(), TBJName.Text.ToString() + "SendMail",TBMsgColName.Text.ToString(),TBSubject.Text.ToString(), tbemailCol.Text.ToString(),tbmobile.Text.ToString());
          //  addjobsetep();
        }
        catch (Exception ex)
        {
            rowEffected = -9;
            conn.Close();
            lbl_msg.Text = ex.Message;
           
        }
        finally
        {
            conn.Close();
        }
        return rowEffected;
    }

    protected void LBjobSave_Click(object sender, EventArgs e)
    {
        if (LBjobSave.Text == "Save")
        {
            CreateSQLJob();
        }
    }
      
    public void fetchjob()
    {
         string query = "select * from msdb.dbo.sysjobs order by date_created desc";
        //string query = "select * from msdb.dbo.sysjobs,msdb.dbo.sysjobsteps where sysjobs.job_id = sysjobsteps.job_id and sysjobsteps.database_name='Esdata' order by date_created desc ";
        DataSet jds = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, query);
        gvjob.DataSource = jds.Tables[0];
        gvjob.DataBind();
    }

    protected void gvjob_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "RecEdit")
        {
            LBjobSave.Text = "Modify";  
            fetchjobstep(e.CommandArgument.ToString());
            fetchjobsch(e.CommandArgument.ToString());
            LBNewStep.Enabled = true;
            LBNewStep.Visible = true;
            
            //LBInsertSch.Enabled = false;
            //LBInsertSch.Visible = false;

        }
        else if (e.CommandName.ToString() == "RecDelete")
        {
            deletejob(e.CommandArgument.ToString());
            //  LBjobSave.Text = "DELETE";
            Response.Redirect("Resident.aspx");
        }
        else if (e.CommandName.ToString() == "resendMail")
        {
          //  LBjobSave.Text = "sendMail";
            sendFailedMAIl();
            Response.Redirect("Resident.aspx");
        }
     
    }

    public void fetchjobstep(string id)
    {
        string query = "select * from msdb.dbo.sysjobs,msdb.dbo.sysjobsteps where database_name = '"+databaseName+ "'  and    msdb.dbo.sysjobs.job_id = msdb.dbo.sysjobsteps.job_id and msdb.dbo.sysjobs.job_id = '" + id+"' ";
        DataSet jds = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, query);
        TBJName.Text = jds.Tables[0].Rows[0]["name"].ToString();
        Tbjetdate.Text= jds.Tables[0].Rows[0]["date_created"].ToString();
        tbstarttime.Text = "Last run on : "+jds.Tables[0].Rows[0]["last_run_time"].ToString();
        TBCreated.Text = jds.Tables[0].Rows[0]["date_created"].ToString();
        TBModified.Text = jds.Tables[0].Rows[0]["date_modified"].ToString();
        gvstep.DataSource = jds.Tables[0];
        gvstep.DataBind();
    }


    public void fetchjobsch(string id)
    {
        string query = "select * from msdb.dbo.sysjobschedules where job_id = '" + id + "' ";
        DataSet jds = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, query);
        gv_sch.DataSource = jds.Tables[0];
        gv_sch.DataBind();
    }

    //public void sendalertMAil(string query)
    //{
    //    query = "select distinct Convert(varchar,b.Vdt,105) as customedate, a.Name,a.Altercode, a.mobile,COUNT(b.vno) as count into tempesdata_new from esdata.dbo.Acm a, esdata.dbo.salepurchase1 b where a.code = b.Acno";  
    //        int startindex = query.LastIndexOf("into");
    //    int Endindex = query.LastIndexOf("from");
    //    string outputstring = query.Substring(startindex + 4, Endindex - startindex - 2);

    //    string messageBody = "Send mail through c# command to execute sp_dbmail executed sussessfully. ";
    //    string subject = "Careers";
    //    using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["LPConnectionString"].ConnectionString))
    //    { 
    //        connection.Open();
    //        SqlCommand cmd = new SqlCommand("msdb.dbo.sp_send_dbmail", connection);
    //        cmd.CommandType = CommandType.StoredProcedure;
    //        cmd.Parameters.Add("@profile_name", SqlDbType.VarChar).Value = "NEW";
    //        cmd.Parameters.Add("@body_format", SqlDbType.VarChar).Value = "HTML";
    //        cmd.Parameters.Add("@recipients", SqlDbType.VarChar).Value = "ritu.laxmayatechnologies@gmail.com";
    //        cmd.Parameters.Add("@subject", SqlDbType.VarChar).Value = subject;
    //        cmd.Parameters.Add("@body", SqlDbType.VarChar).Value = messageBody;   
    //        //cmd.Parameters.Add("@file_attachments ", SqlDbType.NVarChar,-1).Value = uploadCV.FileName;
    //        //cmd.Parameters.Add("@copy_recipients",SqlDbType.VarChar).Value = ;
    //        //cmd.Parameters.Add("@blind_copy_recipients", SqlDbType.VarChar).Value = "";
    //        cmd.ExecuteNonQuery();
    //        connection.Close();
    //    }
    //}

    //
  

    public void addjobsetep()
    {
        try
        {
            using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["LPConnectionString"].ConnectionString))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand("msdb.dbo.sp_add_jobstep", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@job_name", SqlDbType.VarChar).Value = TBJName.Text.ToString();
                cmd.Parameters.Add("@step_name", SqlDbType.VarChar).Value = "stp_sendMail";//tbstepname.Text.ToString();
                cmd.Parameters.Add("@command", SqlDbType.VarChar).Value =  "Exec "+TBJName.Text.ToString()+"SendMail"; //TbQuery.Text.ToString();
                //cmd.Parameters.Add("@on_success_action", SqlDbType.VarChar).Value = "";
                //cmd.Parameters.Add("@on_success_step_id", SqlDbType.NVarChar, -1).Value = "";
                //cmd.Parameters.Add("@on_fail_action", SqlDbType.VarChar).Value = "";
                //cmd.Parameters.Add("@on_fail_step_id", SqlDbType.VarChar).Value = "";
                //cmd.Parameters.Add("@on_fail_step_id", SqlDbType.VarChar).Value = "";
                //cmd.Parameters.Add("@server", SqlDbType.VarChar).Value = "";
                //cmd.Parameters.Add("@database_name", SqlDbType.VarChar).Value = "";
                //cmd.Parameters.Add("@retry_attempts", SqlDbType.VarChar).Value = "";
                //cmd.Parameters.Add("@retry_interval", SqlDbType.VarChar).Value = "";
                //cmd.Parameters.Add("@os_run_priority", SqlDbType.VarChar).Value = "";
                //cmd.Parameters.Add("@output_file_name", SqlDbType.VarChar).Value = "";
                cmd.ExecuteNonQuery();
                connection.Close();
            }
        }
        catch (Exception e)
        {

        }
    }

    public void deletejobsetep()
    {
        string delsql = " DELETE FROM msdb.dbo.sysjobschedules WHERE job_id = ";
        int i = Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteNonQuery(Connection.connects(), CommandType.Text, delsql);
    }

    public void addjobschedule()
    {
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["LPConnectionString"].ConnectionString))
        {
            connection.Open();
            SqlCommand cmd = new SqlCommand("msdb.dbo.sp_add_schedule", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@schedule_name ", SqlDbType.VarChar).Value = "NEW";
            cmd.Parameters.Add("@enabled", SqlDbType.VarChar).Value = "HTML";
            cmd.Parameters.Add("@freq_type", SqlDbType.VarChar).Value = "ritu.laxmayatechnologies@gmail.com";
            cmd.Parameters.Add("@freq_interval", SqlDbType.VarChar).Value = "";
            cmd.Parameters.Add("@active_start_date", SqlDbType.VarChar).Value = "sql query command";
            cmd.Parameters.Add("@active_start_time", SqlDbType.VarChar).Value = "";
            cmd.ExecuteNonQuery();
            connection.Close();
        }
    }

    public void updatejobschedule()
    {
        string[] st = tbsdate.Text.Split('/');   
        string sdt = st[2] + st[0] + st[1];
        string[] est = tbedate.Text.Split('/');
        string edt = st[2] + st[0] + st[1];
        //string stime = "015959";
        //string etime = "235959";
        DateTime d;
        if (tbStartingAt.Text.Length == 0)
        {
          d = DateTime.Parse(txttime.Text);  
        }
        else {
             d = DateTime.Parse(tbStartingAt.Text);
        }
        
        DateTime d2 = DateTime.Parse(tbendingAt.Text);
        string a = d.ToString("HH:mm"); //tbStartingAt.Text.Replace(":","");
        string b = d2.ToString("HH:mm"); 
        string stime = a.Replace(":", "");
        string etime = b.Replace(":", "");



        int freq_interval = 0, freq_subday_type = 0, freq_subday_interval = 0, freq_relative_interval = 0, freq_recurrence_factor = 1;
        int freqtype = Convert.ToInt32(DDLOccurFreq.SelectedValue.ToString());
        int sun = 1;
        int mon = 2;
        int tues = 4;
        int wed = 8;
        int thr = 16;
        int fri = 32;
        int sat = 64;


        switch (freqtype)
        {
            case 4:
                freq_interval = 1|2|4|8|16|32|64;
                freq_recurrence_factor = Convert.ToInt32(rechday.Text.ToString());
                break;
            case 8:
                freq_recurrence_factor = Convert.ToInt32(rechweek.Text.ToString());
                if (cbsunday.Checked)
                {
                    freq_interval = sun; 
                }
                if (cbmunday.Checked)
                {
                    freq_interval = freq_interval | mon;
                }
                if (cbtuesday.Checked)
                {
                    freq_interval = freq_interval | tues;
                }
                if (cbwednesday.Checked)
                {
                    freq_interval = freq_interval | wed;
                }
                if (cbthrusday.Checked)
                {
                    freq_interval = freq_interval | thr;
                }
                if (cbfriday.Checked)
                {
                    freq_interval = freq_interval | fri;
                }
                if (cbsaturday.Checked)
                {
                    freq_interval = freq_interval | sat;
                }
                break;
            case 16:
                if (rbldaythe.SelectedValue.ToString() == "Day")
                {
                    freq_interval = Convert.ToInt32(lblDay.Text.ToString());
                    freq_recurrence_factor = Convert.ToInt32(lblmonth.Text.ToString());
                }
                else if (rbldaythe.SelectedValue.ToString() == "The")
                {                    
                    freq_interval = Convert.ToInt32(ddlweekday.SelectedValue.ToString());
                    freq_recurrence_factor = Convert.ToInt32(tbrechmonthpnlnum.Text.ToString());
                    freq_relative_interval = Convert.ToInt32(ddlweekcount.Text.ToString());
                }
                break;
            default:
                break;
        }
       
        
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["LPConnectionString"].ConnectionString))
        {

            connection.Open();
            SqlCommand cmd = new SqlCommand("msdb.dbo.sp_update_schedule", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@schedule_id ", SqlDbType.VarChar).Value = lblschID.Value;
            cmd.Parameters.Add("@new_name", SqlDbType.VarChar).Value = tbschname.Text.ToString();
            cmd.Parameters.Add("@enabled", SqlDbType.VarChar).Value = "1";
            cmd.Parameters.Add("@freq_type", SqlDbType.VarChar).Value = freqtype;
            cmd.Parameters.Add("@freq_interval", SqlDbType.VarChar).Value = freq_interval;

            cmd.Parameters.Add("@freq_subday_type", SqlDbType.VarChar).Value = freq_subday_type;
            cmd.Parameters.Add("@freq_subday_interval", SqlDbType.VarChar).Value = freq_subday_interval;
            cmd.Parameters.Add("@freq_relative_interval", SqlDbType.VarChar).Value = freq_relative_interval;
            cmd.Parameters.Add("@freq_recurrence_factor", SqlDbType.VarChar).Value = freq_recurrence_factor;

            cmd.Parameters.Add("@active_start_date", SqlDbType.VarChar).Value = sdt;  
            cmd.Parameters.Add("@active_start_time", SqlDbType.VarChar).Value = stime;
            cmd.Parameters.Add("@active_end_date ", SqlDbType.VarChar).Value = edt;
            cmd.Parameters.Add("@active_end_time ", SqlDbType.VarChar).Value = etime;
            cmd.ExecuteNonQuery();  
            connection.Close();
        }
    }

    public void startJob()
    {
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["LPConnectionString"].ConnectionString))
        {
            connection.Open();
            SqlCommand cmd = new SqlCommand("msdb.dbo.sp_start_job", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@job_name", SqlDbType.VarChar).Value = "NEW";
            cmd.ExecuteNonQuery();
            connection.Close();
        }
    }

    public void stopJob()
    {
        //   sp_stop_job
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["LPConnectionString"].ConnectionString))
        {
            connection.Open();
            SqlCommand cmd = new SqlCommand("msdb.dbo.sp_stop_job", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@job_name", SqlDbType.VarChar).Value = "NEW";
            cmd.ExecuteNonQuery();
            connection.Close();
        }
    }

    public void fetchstepfromstepID(string id)
    {
        string query = "select * from msdb.dbo.sysjobsteps where database_name = '"+databaseName+"'  and  step_uid = '" + id + "' ";  
        DataSet jds = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, query);
        tbstepname.Text = jds.Tables[0].Rows[0]["step_name"].ToString();
        TbQuery.Text = jds.Tables[0].Rows[0]["command"].ToString();
        //DropDownList4.ClearSelection();
        //DropDownList4.SelectedValue= jds.Tables[0].Rows[0]["on_success_action"].ToString();
        //DropDownList6.ClearSelection();
        //DropDownList4.SelectedValue = jds.Tables[0].Rows[0]["on_fail_action"].ToString();
        hdn_stepId.Value= jds.Tables[0].Rows[0]["step_id"].ToString();  


    }
    //change qrystep
    protected void gvstep_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "RecEdit")
        {
            fetchstepfromstepID(e.CommandArgument.ToString());
            ModalPopupExtender1.Show();
            btnmodalsavestep.Visible = true;
        }
       
    }
    //btn evnt only for update qry
    protected void btnmodalsavestep_Click(object sender, EventArgs e)
    {
        try
        {
            modifyjob();
           
        }
        catch (Exception e1)
        {
            string str = e1.Message.ToString(); 
        }
    }

    public void modifyjob()
    {
        try
        {
            try
            {
                int i = SqlHelper.ExecuteNonQuery(Connection.connects(), CommandType.Text, "DROP PROC " + TBJName.Text.ToString() + "SendMail");
            }
            catch (Exception dd) { }

                string query = TbQuery.Text.Trim();
            query = query.Replace(System.Environment.NewLine, " ");
            RecreateMailCursor(query, tbColNAme.Text.ToString(), TBJName.Text.ToString() + "SendMail", TBMsgColName.Text.ToString(), TBSubject.Text.ToString(), tbemailCol.Text.ToString(),tbmobile.Text.ToString());
      
        }
        catch (Exception e)
        {
            lbl_msg.Text = e.Message.ToString();
        }
    }
    //scheduler gridview options
    protected void gv_sch_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "RecAdd")
        {
           // addjobschedule();
        }
        else if (e.CommandName.ToString() == "RecEdit")
        {
            lblschID.Value = e.CommandArgument.ToString();
            ModalPopupExtender2.Show();
            
           // updatejobschedule();
        } 
    }

    public void createMailCursor(string query,string tbcolname,string storedprocedure ,string message ,string subject, string email,string mobile )  
    {

         query = query.Replace(@"/ ", "");
        string[] decvar = tbcolname.Split(',');
        int decvarlen = decvar.Length;
        StringBuilder paramstr = new StringBuilder(" DECLARE " + "@" + decvar[0].ToString() + " varchar(1000) ");
        for (int i = 1; i < decvarlen; i++)
        {
              paramstr.Append("DECLARE " +  "@" + decvar[i].ToString() + " varchar(1000) ");
        }
        string aaa = paramstr.ToString();
        StringBuilder tempvarstr = new StringBuilder("@" + decvar[0].ToString() + ",");
        for (int j = 1; j < decvarlen; j++)
        {
            tempvarstr.Append("@" + decvar[j].ToString() + ",");
        }
        string aaaa = tempvarstr.ToString();
        
        try
        {
            string spsql = " CREATE PROC " + storedprocedure +
                " AS" +
                " DECLARE @email_subject nvarchar(1000) " +
                " DECLARE @email_body nvarchar(max)";  //+
               
            string decparamstr =  "   "+aaa; 
            string spsqlremain = " DECLARE eMailCursor CURSOR FAST_FORWARD FOR"; 
        
           

            string remainqry = " OPEN eMailCursor " +
        " FETCH NEXT FROM eMailCursor INTO " + aaaa.Remove(tempvarstr.Length - 1, 1) + " " +
        "WHILE @@FETCH_STATUS = 0    " +
        "BEGIN " +
        " EXEC msdb.dbo.sp_send_dbmail     " +
            " @profile_name = 'P2',    " +
            " @recipients = @"+email+",    " +
            " @subject = "+subject+", " + 
            " @body =  @" + message + ", " + //@pbody,    " +
            " @body_format = 'HTML'    exec pr_SendSmsSQL @"+mobile + ",@" + message + ",'';";
            // send sms code here 



            string fetchstr = "   FETCH NEXT FROM eMailCursor INTO   " + aaaa.Remove(tempvarstr.Length-1 , 1) + "  END  CLOSE eMailCursor    DEALLOCATE eMailCursor ";

                string freshstr = spsql.Trim() + decparamstr.Trim() + spsqlremain.ToString() + " " + query.Trim() + " " + remainqry.Trim() + fetchstr.ToString();
                string sss = freshstr.Replace("\r\n", " ");
                string f = sss.Replace(@"\", ""); 
              string j = f.Replace('\"', '\'');
                int i = SqlHelper.ExecuteNonQuery(Connection.connects(), CommandType.Text, j); 

        }
        catch (Exception e)
        {

        }

    }
    
   public void sendFailedMAIl()
    {
        try
        {
            string qry = @"DECLARE @to        varchar(max)
DECLARE @copy    varchar(max)
DECLARE @title    nvarchar(255)
DECLARE @msg    nvarchar(max)  
DECLARE FaileMailCursor CURSOR FAST_FORWARD FOR     
SELECT  recipients,  copy_recipients,  [subject], body
FROM msdb.dbo.sysmail_faileditems
OPEN FaileMailCursor      
FETCH NEXT FROM FaileMailCursor INTO @to, @copy, @title,@msg      
WHILE @@FETCH_STATUS = 0    
BEGIN    
 print @copy    
  EXEC msdb.dbo.sp_send_dbmail     
    @profile_name = 'P2',    
    @recipients = @to,    
    @subject = @title,    
    @body = @msg,    
    @body_format = 'HTML'    
 FETCH NEXT FROM FaileMailCursor INTO @to, @copy, @title,@msg      
END        
CLOSE FaileMailCursor     
DEALLOCATE FaileMailCursor";
       string      query = qry.Replace(System.Environment.NewLine, " ");
            int i = SqlHelper.ExecuteNonQuery(Connection.connects(), CommandType.Text, query);

        }
        catch (Exception e)
        {
            lbl_msg.Text = e.Message;       
        }
    }

    public void viewsentmail()
    {
        string qry = "SELECT send_request_date , send_request_user  , subject, body FROM msdb.dbo.sysmail_sentitems WHERE sent_date >= DATEADD(dd,-7, getdate()) order by send_request_date desc ";
        int i = SqlHelper.ExecuteNonQuery(Connection.connects(), CommandType.Text, qry);  
    }

    public void deletejob(string jobid)
    {
        string qry = @"EXEC msdb.dbo.sp_delete_job
              @job_id = N'"+jobid+"'";
        string query = qry.Replace(System.Environment.NewLine, " ");
        int i = SqlHelper.ExecuteNonQuery(Connection.connects(), CommandType.Text, query);

    }


    public void RecreateMailCursor(string query, string tbcolname, string storedprocedure, string message, string subject, string email,string mobile)
    {
   
        query = query.Replace(@"/ ", "");
        string[] decvar = tbcolname.Split(',');
        int decvarlen = decvar.Length;
        StringBuilder paramstr = new StringBuilder(" DECLARE " + "@" + decvar[0].ToString() + " varchar(1000) ");
        for (int i = 1; i < decvarlen; i++)
        {
            paramstr.Append("DECLARE " + "@" + decvar[i].ToString() + " varchar(1000) ");
        }
        string aaa = paramstr.ToString();
        StringBuilder tempvarstr = new StringBuilder("@" + decvar[0].ToString() + ",");
        for (int j = 1; j < decvarlen; j++)
        {
            tempvarstr.Append("@" + decvar[j].ToString() + ",");
        }
        string aaaa = tempvarstr.ToString();

        try
        {
            string spsql = " CREATE PROC " + storedprocedure +
                " AS" +
                " DECLARE @email_subject nvarchar(1000) " +
                " DECLARE @email_body nvarchar(max)";  //+

            string decparamstr = "   " + aaa;
            string spsqlremain = " DECLARE eMailCursor CURSOR FAST_FORWARD FOR";



            string remainqry = " OPEN eMailCursor " +
        " FETCH NEXT FROM eMailCursor INTO " + aaaa.Remove(tempvarstr.Length - 1, 1) + " " +
        "WHILE @@FETCH_STATUS = 0    " +
        "BEGIN " +
        " EXEC msdb.dbo.sp_send_dbmail     " +
            " @profile_name = 'P2',    " +
            " @recipients = @" + email + ",    " +
            " @subject = " + subject + ", " +
            " @body =  @" + message + ", " + //@pbody,    " + 
            " @body_format = 'HTML' exec pr_SendSmsSQL @" + mobile + ",@" + message + ",'';";

            string fetchstr = "   FETCH NEXT FROM eMailCursor INTO   " + aaaa.Remove(tempvarstr.Length - 1, 1) + "  END  CLOSE eMailCursor    DEALLOCATE eMailCursor ";

            string freshstr = spsql.Trim() + decparamstr.Trim() + spsqlremain.ToString() + " " + query.Trim() + " " + remainqry.Trim() + fetchstr.ToString();
            string sss = freshstr.Replace("\r\n", " ");
            string f = sss.Replace(@"\", "");
            string j = f.Replace('\"', '\'');
            int i = SqlHelper.ExecuteNonQuery(Connection.connects(), CommandType.Text, j);

        }
        catch (Exception e)
        {
            lbl_msg.Text = e.Message.ToString(); 
        }

    }


    protected void lbsaveSchedule_Click(object sender, EventArgs e)
    {
        updatejobschedule();        
    }

    protected void DDlSchType_SelectedIndexChanged(object sender, EventArgs e)
    {
      
        
    }

    protected void DDLOccurFreq_SelectedIndexChanged(object sender, EventArgs e)
    {
        string ftype = DDLOccurFreq.SelectedValue.ToString();
        switch (ftype)
        {
            case "4":
                {
                    tbrechrweek.Visible = false;
                    pnlweekday.Visible = false;
                    rechweek.Visible = false;
                    tbrechr.Visible = true;
                    rechday.Visible = true;
                    pnlfreqmonth.Visible = false;
                    pnlfreqmonthThe.Visible = false;
                    pnlfreqmonthDay.Visible = false;
                    break;
                }
            case "8":
                {
                    tbrechr.Visible = false;
                    rechday.Visible = false;
                    rechweek.Visible = true;
                    tbrechrweek.Visible = true;
                    pnlweekday.Visible = true;
                    pnlfreqmonth.Visible = false;
                    pnlfreqmonthThe.Visible = false;
                    pnlfreqmonthDay.Visible = false;
                    break;
                }
            case "16":
                {
                    pnlweekday.Visible = false;
                    tbrechr.Visible = false;
                    tbrechrweek.Visible = false;
                    rechday.Visible = false;
                    rechweek.Visible = false;
                    pnlfreqmonth.Visible = true;
                    break;
                }
            default:
                break;
        }
    }

    protected void rbldaythe_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (rbldaythe.SelectedValue == "Day")
        {
            pnlfreqmonthDay.Visible = true;
            pnlfreqmonthThe.Visible = false;
        }
        else {
            pnlfreqmonthDay.Visible = false;
            pnlfreqmonthThe.Visible = true;
        }
    }

    protected void rblistIsenddate_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (rblistIsenddate.SelectedValue == "End Date")  
        {
            tbedate.Enabled = true;
        }
        else
        {
            tbedate.Enabled = false;
        }

    }



    protected void rblonceordaily_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (rblonceordaily.SelectedValue.ToString() == "Once")
        {
            txttime.Enabled = true;
            tboccuronceAt.Enabled = false;
            ddlhms.Enabled = false;
            tbStartingAt.Enabled = false;
        }
        else {
            txttime.Enabled = false;
            tboccuronceAt.Enabled = true;
            ddlhms.Enabled = true;
            tbStartingAt.Enabled = true;
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        ModalPopupExtender2.Hide();
    }

    
}
