﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for Connection
/// </summary>
public class Connection
{
    public static string connection = "";
    public static string connection1 = "";

    public static string connect()
    {
        if (clsConnectionSql.con.State == ConnectionState.Open)
        {
            clsConnectionSql.con.Close();
        }
        connection = System.Configuration.ConfigurationManager.ConnectionStrings["LPConnectionString"].ToString();
        return connection;
    }

    public static void close()
    {
        if (clsConnectionSql.con.State == ConnectionState.Open)
        {
            clsConnectionSql.con.Close();
        }
    }

    
}