﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using Microsoft.ApplicationBlocks.Data;
using System.Web.UI.WebControls;

public partial class AdminPannel_Blank : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        fetchjob();
        fetchfailmail();
        fetchsendmobile();
    }

    public void fetchjob()
    {
       
        DataSet jds = Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteDataset(Connection.connects(), CommandType.StoredProcedure, "msdb.dbo.sp_help_jobactivity");
        gvjob.DataSource = jds.Tables[0];
        gvjob.DataBind();
    }

    public void fetchfailmail()
    {
        DataSet jds = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, "SELECT top 1000 *  FROM MSDB.DBO.sysmail_faileditems  order by sent_date desc ");
        gv_failedmail.DataSource = jds.Tables[0];
        gv_failedmail.DataBind();  
    }


    public void fetchsendmobile()
    {

        DataSet jds = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, "SELECT * FROM esdata.dbo.send_log order by 6 desc ");
        gv_message.DataSource = jds.Tables[0];
        gv_message.DataBind();
    }

    protected void gvjob_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvjob.PageIndex = e.NewPageIndex;
        fetchjob();
    }

    protected void gv_failedmail_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gv_failedmail.PageIndex = e.NewPageIndex;
        fetchfailmail();
    }


    public void sendFailedMAIl()
    {
        try
        {
            string qry = @"DECLARE @to        varchar(max)
DECLARE @copy    varchar(max)
DECLARE @title    nvarchar(255)
DECLARE @msg    nvarchar(max)  
DECLARE FaileMailCursor CURSOR FAST_FORWARD FOR     
SELECT  recipients,  copy_recipients,  [subject], body
FROM msdb.dbo.sysmail_faileditems
OPEN FaileMailCursor      
FETCH NEXT FROM FaileMailCursor INTO @to, @copy, @title,@msg      
WHILE @@FETCH_STATUS = 0    
BEGIN    
 print @copy    
  EXEC msdb.dbo.sp_send_dbmail     
    @profile_name = 'P2',    
    @recipients = @to,    
    @subject = @title,    
    @body = @msg,    
    @body_format = 'HTML'    
 FETCH NEXT FROM FaileMailCursor INTO @to, @copy, @title,@msg      
END        
CLOSE FaileMailCursor     
DEALLOCATE FaileMailCursor";
            string query = qry.Replace(System.Environment.NewLine, " ");
            int i = SqlHelper.ExecuteNonQuery(Connection.connects(), CommandType.Text, query);

        }
        catch (Exception e)
        {
            lbl_msg.Text = e.Message;
        }
    }

    protected void lbsendMail_Click(object sender, EventArgs e)
    {
        sendFailedMAIl();
    }

    protected void gv_message_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gv_message.PageIndex = e.NewPageIndex;
        fetchsendmobile();
    }

    protected void tbSearch_TextChanged(object sender, EventArgs e)
    {
        if (tbSearch.Text.Length > 0)
        {
            string qry = "SELECT * FROM MSDB.DBO.sysmail_faileditems where recipients like '%"+tbSearch.Text+"%' order by sent_date desc";
            DataSet jds = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, qry);
            gv_failedmail.DataSource = jds.Tables[0];
            gv_failedmail.DataBind(); 
        }
        else {

        }
    }

    protected void tbSearchmsg_TextChanged(object sender, EventArgs e)
    {
        if (tbSearchmsg.Text.Length > 0)
        {
            DataSet jds = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, "SELECT * FROM esdata.dbo.send_log where mobile = '" + tbSearchmsg.Text + "'  order by 6 desc ");
            gv_message.DataSource = jds.Tables[0];
            gv_message.DataBind();
        }
        else
        {

        }
    }
}